package com.project;

import java.io.File;
import java.nio.file.Files;
import java.util.*;

public class JSONQuestionAdapter implements QuestionDataAdapter {
    @Override
    public List<Question> loadQuestions(File file) {
        List<Question> questions = new ArrayList<>();
        
        try {
            String content = Files.readString(file.toPath());
            content = content.trim();
            
            if (content.startsWith("[") && content.endsWith("]")) {
                content = content.substring(1, content.length() - 1).trim();
            }
            
            String[] questionObjects = content.split("\\},\\s*\\{");
            
            for (String questionStr : questionObjects) {
                String cleanStr = questionStr.trim();
                if (!cleanStr.startsWith("{")) {
                    cleanStr = "{" + cleanStr;
                }
                if (!cleanStr.endsWith("}")) {
                    cleanStr = cleanStr + "}";
                }
                
                Question question = parseQuestionObject(cleanStr);
                if (question != null) {
                    questions.add(question);
                }
            }
            
        } catch (Exception e) {
            System.err.println("Error loading JSON file: " + e.getMessage());
            e.printStackTrace();
        }
        
        return questions;
    }
    
    private Question parseQuestionObject(String jsonObject) {
        try {
            // Extract fields using more reliable parsing
            String category = extractJsonValue(jsonObject, "Category");
            String valueStr = extractJsonValue(jsonObject, "Value");
            String questionText = extractJsonValue(jsonObject, "Question");
            String correctAnswer = extractJsonValue(jsonObject, "CorrectAnswer");
            
            if (category.isEmpty() || valueStr.isEmpty() || questionText.isEmpty() || correctAnswer.isEmpty()) {
                return null;
            }
            
            int value = Integer.parseInt(valueStr.trim());
            
            // Extract options if they exist
            Map<String, String> options = new HashMap<>();
            String optionsStr = extractJsonObject(jsonObject, "Options");
            
            if (!optionsStr.isEmpty()) {
                options.put("A", extractJsonValue(optionsStr, "A"));
                options.put("B", extractJsonValue(optionsStr, "B"));
                options.put("C", extractJsonValue(optionsStr, "C"));
                options.put("D", extractJsonValue(optionsStr, "D"));
                
                return new Question(category, value, questionText, options, correctAnswer);
            } else {
                return new Question(category, value, questionText, correctAnswer);
            }
            
        } catch (Exception e) {
            System.err.println("Error parsing question: " + e.getMessage());
            return null;
        }
    }
    
    private String extractJsonValue(String json, String field) {
        String pattern = "\"" + field + "\"\\s*:\\s*\"([^\"]*)\"";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
        java.util.regex.Matcher m = p.matcher(json);
        
        if (m.find()) {
            return m.group(1);
        }
        
        pattern = "\"" + field + "\"\\s*:\\s*([^,\\}]+)";
        p = java.util.regex.Pattern.compile(pattern);
        m = p.matcher(json);
        
        if (m.find()) {
            String value = m.group(1).trim();
            // Remove any trailing comma
            if (value.endsWith(",")) {
                value = value.substring(0, value.length() - 1);
            }
            return value;
        }
        
        return "";
    }
    
    private String extractJsonObject(String json, String field) {
        String pattern = "\"" + field + "\"\\s*:\\s*\\{([^}]*)\\}";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
        java.util.regex.Matcher m = p.matcher(json);
        
        if (m.find()) {
            return "{" + m.group(1) + "}";
        }
        
        return "";
    }
}